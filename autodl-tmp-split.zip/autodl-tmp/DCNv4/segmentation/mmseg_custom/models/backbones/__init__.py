# --------------------------------------------------------
# FlashInternImage
# Copyright (c) 2023 OpenGVLab
# Licensed under The MIT License [see LICENSE for details]
# --------------------------------------------------------

from .flash_intern_image import FlashInternImage

__all__ = ['FlashInternImage']
