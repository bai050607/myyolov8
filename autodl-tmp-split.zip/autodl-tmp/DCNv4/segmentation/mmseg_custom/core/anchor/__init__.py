# Copyright (c) Shanghai AI Lab. All rights reserved.
from .point_generator import MlvlPointGenerator  # noqa: F401,F403
