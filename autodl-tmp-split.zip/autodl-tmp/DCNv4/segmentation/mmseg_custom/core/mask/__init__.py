# Copyright (c) Shanghai AI Lab. All rights reserved.
from .utils import mask2bbox  # noqa: F401,F403
